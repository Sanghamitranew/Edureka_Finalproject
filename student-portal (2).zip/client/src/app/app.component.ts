import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<h1>Welcome to Student Portal</h1><app-student></app-student>'
})
export class AppComponent { }
