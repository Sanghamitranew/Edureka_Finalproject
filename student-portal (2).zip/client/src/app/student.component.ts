import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html'
})
export class StudentComponent {
  registrationNumber = '';
  name = '';
  email = '';
  password = '';

  constructor(private http: HttpClient) {}

  registerStudent() {
    const student = {
      registrationNumber: this.registrationNumber,
      name: this.name,
      email: this.email,
      password: this.password
    };
    this.http.post('http://localhost:5000/api/students/register', student)
      .subscribe(response => {
        console.log('Student registered:', response);
      });
  }
}
