const mongoose = require('mongoose');

const StudentSchema = new mongoose.Schema({
  registrationNumber: { type: String, required: true, unique: true },
  email: String,
  name: String,
  password: String,
  isBlocked: { type: Boolean, default: false },
  profile: {
    phone: String,
    address: String,
  },
  leaveRequests: [
    {
      date: String,
      reason: String,
      status: { type: String, enum: ['Pending', 'Approved', 'Rejected'], default: 'Pending' },
    },
  ],
});

module.exports = mongoose.model('Student', StudentSchema);
