const express = require('express');
const router = express.Router();
const Student = require('../models/Student');

router.get('/students', async (req, res) => {
  const students = await Student.find();
  res.json(students);
});

router.put('/student/:id/leave/:leaveId', async (req, res) => {
  const { id, leaveId } = req.params;
  const { status } = req.body;
  try {
    const student = await Student.findById(id);
    const leave = student.leaveRequests.id(leaveId);
    leave.status = status;
    await student.save();
    res.json({ message: `Leave ${status}` });
  } catch (err) {
    res.status(400).json({ error: 'Failed to update leave status' });
  }
});

module.exports = router;
