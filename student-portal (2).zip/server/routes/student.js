const express = require('express');
const router = express.Router();
const Student = require('../models/Student');

router.post('/register', async (req, res) => {
  const { registrationNumber, name, email, password } = req.body;
  try {
    const student = new Student({ registrationNumber, name, email, password });
    await student.save();
    res.status(201).json(student);
  } catch (error) {
    res.status(400).json({ error: 'Registration failed' });
  }
});

router.post('/:id/leave', async (req, res) => {
  const { id } = req.params;
  const { date, reason } = req.body;
  try {
    const student = await Student.findById(id);
    student.leaveRequests.push({ date, reason });
    await student.save();
    res.json(student);
  } catch (err) {
    res.status(400).json({ error: 'Leave application failed' });
  }
});

module.exports = router;
